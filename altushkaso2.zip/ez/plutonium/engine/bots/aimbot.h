namespace engine {
    class aimbot {
    private:
        static std::unique_ptr<aimbot> instance;
        plutonium_t *_cheat;

    public:
        enum bone_type {
            head,
            neck,
            stomach,
            hands,
            legs,
            foots
        };

        static aimbot *create() {
            instance = std::make_unique<aimbot>();
            instance->_cheat = _g_cheat.load();
            return instance.get();
        }

        float get_camera_angle(const Vector3 &screen_position) const {
            if (screen_position.z <= 0.5f) return 999.f;

            auto &screen = unity::screen::get_screen();
            float width = static_cast<float>(screen.get_width());
            float height = static_cast<float>(screen.get_height());

            return std::hypot(width / 2 - screen_position.x, height / 2 - screen_position.y);
        }

        bool in_rect(const Vector3 &player_screen, float fovx, float fovy) const {
            if (player_screen.z <= 0.5f) return false;

            auto &screen = unity::screen::get_screen();
            int fovLeft = (screen.get_width() - fovx) / 2;
            int fovTop = (screen.get_height() - fovy) / 2;
            int fovRight = fovLeft + fovx;
            int fovBottom = fovTop + fovy;

            return (player_screen.x >= fovLeft && player_screen.x <= fovRight) &&
                   (player_screen.y >= fovTop && player_screen.y <= fovBottom);
        }

        float distance_to(const Vector3 &player_screen) const {
            if (player_screen.z <= 0.5f) return 999999999.f;

            auto &screen = unity::screen::get_screen();
            return Vector2::Distance(
                Vector2(screen.get_width() / 2, screen.get_height() / 2),
                Vector2(player_screen.x, player_screen.y)
            );
        }

        float distance_to_player(const Vector3 &position, const Vector3 &camera_position, const Quaternion &camera_rotation, float field_of_view) const {
            Vector3 player_screen = world_to_screen(position, camera_position, camera_rotation, field_of_view);
            return (player_screen.z > 0.5f) ? distance_to(player_screen) : 99999999.f;
        }

        static bool check_bone(axlebolt::bone_type bone) {
            const auto &vars = menu::vars;
            const std::array<bool, 6> enabled_bones = {vars.bools.enable_bone};

            return (enabled_bones[aimbot::head] && bone == axlebolt::head) ||
                   (enabled_bones[aimbot::neck] && bone == axlebolt::neck) ||
                   (enabled_bones[aimbot::stomach] && (bone == axlebolt::spine1 || bone == axlebolt::spine2 || bone == axlebolt::hip)) ||
                   (enabled_bones[aimbot::hands] && bone >= axlebolt::leftupperarm && bone <= axlebolt::righthand) ||
                   (enabled_bones[aimbot::legs] && bone != axlebolt::leftfoot && bone >= axlebolt::leftthigh && bone <= axlebolt::rightcalf) ||
                   (enabled_bones[aimbot::foots] && (bone == axlebolt::leftfoot || bone == axlebolt::rightfoot));
        }

        bone_t get_filtered_bone(player_t *&enemies, menu::cvars &vars, Vector3 &camera_position, Quaternion &camera_rotation, float &field_of_view) {
            bone_t best_bone{.visible = false};
            float min_distance = std::numeric_limits<float>::max();

            for (int i = 0; i < MAX_PLAYERS_COUNT; i++) {
                player_t &enemy = enemies[i];
                if (!enemy.is_valid() || (enemy.is_untouchable && vars.bools.enable_untouchable_check)) continue;

                bone_t bone = get_visible_bone(enemy, vars, camera_position, camera_rotation, field_of_view);
                if (!bone.visible) continue;

                float distance = distance_to_player(bone.position, camera_position, camera_rotation, field_of_view);
                if (distance < min_distance) {
                    min_distance = distance;
                    best_bone = bone;
                }
            }
            return best_bone;
        }
    };

    std::unique_ptr<aimbot> aimbot::instance{nullptr};

    void gun_controller__execute_commands(axlebolt::gun_controller *_this, axlebolt::weapon_command cmd, float duration, float time) {
        auto *_cheat = _g_cheat.load();
        auto *_aimbot = _cheat->_aimbot;
        auto &vars = menu::cvars::vars();

        if (_this && vars.bools.enable_aimbot && !vars.bools.enable_silent && (cmd.to_fire || !vars.bools.enable_firecheck)) {
            unity::camera *camera = unity::camera::get_main();
            auto *camera_transform = camera->get_component()->get_transform();
            Vector3 camera_position = camera_transform->get_position();
            Quaternion camera_rotation = camera_transform->get_rotation();
            float fov = camera->get_fieldOfView();

            axlebolt::player_controller *local = _this->player;
            if (local) {
                auto *&enemies = _cheat->_players->get_enemies();
                bone_t bone = _aimbot->get_filtered_bone(enemies, vars, camera_position, camera_rotation, fov);
                if (bone.visible) {
                    float t = 1.f - (vars.floats.aimbot_smooth / 100.f);
                    Quaternion lookRotation = Quaternion::LookRotation((bone.position - camera_position));

                    auto *aim_data = local->get_aiming_data();
                    Quaternion rotation = Quaternion::Slerp(
                        FromEuler(Vector3{aim_data->current_aim_angle.x, aim_data->current_euler_angle.y, 0} * 0.017453292f),
                        lookRotation,
                        t * (unity::time::get_deltaTime() / (0.167f / 4))
                    );

                    Vector3 eulerAngles = ToEulerRad(rotation);
                    aim_data->current_aim_angle.x = eulerAngles.x;
                    aim_data->current_euler_angle.y = eulerAngles.y;
                }
            }
        }

        axlebolt::gun_controller::execute_commands(_this, cmd, duration, time);
    }
}