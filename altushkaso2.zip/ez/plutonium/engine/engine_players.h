namespace engine {
    class players {
    private:
        static std::unique_ptr<players> instance;
        axlebolt::player_manager *manager{nullptr};
        axlebolt::player_controls *controls{nullptr};

        std::vector<player_t> enemies;

    public:
        void set_manager() {
            static il2cpp::klass *player_manager_klass = _itcu->find_class(nullptr, "PlayerManager");
            static il2cpp::klass *lazy_singleton_class = static_cast<il2cpp::klass *>(player_manager_klass->_1.parent);
            static void *static_fields = lazy_singleton_class->static_fields;

            manager = *(axlebolt::player_manager **) static_fields;
        }

        std::vector<player_t> &get_enemies() {
            return enemies;
        }

        axlebolt::player_manager *get_manager() {
            return manager;
        }

        axlebolt::player_controls *get_controls() {
            static il2cpp::klass *controls_klass = _itcu->find_class(nullptr, "PlayerControls");
            static void *static_fields = controls_klass->static_fields;
            return *(axlebolt::player_controls **) static_fields;
        }

        axlebolt::player_controller *get_local() {
            return get_controls()->player;
        }

        int count() const {
            return manager ? manager->_playerById->count : 0;
        }

        static players *create() {
            instance = std::make_unique<players>();
            instance->enemies.resize(MAX_PLAYERS_COUNT);
            return instance.get();
        }

        void process_player_data(axlebolt::player_controller *player, axlebolt::player_controller *local, int index) {
            auto &player_data = enemies[index];

            if (local->get_team() == player->get_team() || !player->photon_player) {
                player_data.valid = false;
                return;
            }

            player_data.controller = player;
            player_data.valid = true;

            auto *player_transform = player->get_component()->get_transform();
            auto *biped = player->get_biped_map();

            if (!player_transform || !biped || !biped->Head || !biped->Neck) {
                player_data.valid = false;
                return;
            }

            // Получаем основные позиции
            auto camera = unity::camera::get_main();
            auto camera_transform = camera->get_component()->get_transform();
            Vector3 camera_position = camera_transform->get_position();
            Quaternion camera_rotation = camera_transform->get_rotation();
            float fov = camera->get_fieldOfView();

            std::array<Vector3, 20> bone_positions = {
                world_to_screen(biped->Neck->get_position(), camera_position, camera_rotation, fov),
                world_to_screen(biped->Spine1->get_position(), camera_position, camera_rotation, fov),
                world_to_screen(biped->Spine2->get_position(), camera_position, camera_rotation, fov),
                world_to_screen(biped->Hip->get_position(), camera_position, camera_rotation, fov),
                world_to_screen(biped->LeftShoulder->get_position(), camera_position, camera_rotation, fov),
                world_to_screen(biped->RightShoulder->get_position(), camera_position, camera_rotation, fov),
                world_to_screen(biped->LeftUpperarm->get_position(), camera_position, camera_rotation, fov),
                world_to_screen(biped->RightUpperarm->get_position(), camera_position, camera_rotation, fov),
                world_to_screen(biped->LeftForearm->get_position(), camera_position, camera_rotation, fov),
                world_to_screen(biped->RightForearm->get_position(), camera_position, camera_rotation, fov),
                world_to_screen(biped->LeftHand->get_position(), camera_position, camera_rotation, fov),
                world_to_screen(biped->RightHand->get_position(), camera_position, camera_rotation, fov),
                world_to_screen(biped->LeftThigh->get_position(), camera_position, camera_rotation, fov),
                world_to_screen(biped->RightThigh->get_position(), camera_position, camera_rotation, fov),
                world_to_screen(biped->LeftCalf->get_position(), camera_position, camera_rotation, fov),
                world_to_screen(biped->RightCalf->get_position(), camera_position, camera_rotation, fov),
                world_to_screen(biped->LeftFoot->get_position(), camera_position, camera_rotation, fov),
                world_to_screen(biped->RightFoot->get_position(), camera_position, camera_rotation, fov),
            };

            std::vector<bool> visibility(20);
            constexpr int bullet_layer = 16384;

            for (size_t i = 0; i < bone_positions.size(); i++) {
                visibility[i] = !unity::physics::linecast(camera_position, bone_positions[i], bullet_layer);
            }

            player_data.bone_positions = bone_positions;
            player_data.bone_visibility = visibility;

            player_data.nick = player->photon_player->get_nick();
            player_data.health = player->photon_player->get_health();
            player_data.is_untouchable = player->photon_player->is_untouchable();
        }

        void update_players(axlebolt::player_controller *local) {
            set_manager();
            if (!manager) return;

            auto *players_dict = manager->_playerById;
            int index = 0;

            for (int i = 0; i < players_dict->count && index < MAX_PLAYERS_COUNT; i++) {
                auto *player = players_dict->entries->items[i].value;
                if (!player) continue;

                process_player_data(player, local, index);
                index++;
            }

            for (; index < MAX_PLAYERS_COUNT; index++) {
                enemies[index].valid = false;
            }
        }
    };

    std::unique_ptr<players> players::instance{nullptr};

    void player_controller__update(axlebolt::player_controller *_this) {
        auto *_cheat = _g_cheat.load();
        auto *_players = _cheat->_players;

        axlebolt::player_controller::orig_update(_this);
        if (!_this || !_players) return;

        auto *local = _players->get_local();
        if (local && _this == local) {
            _players->update_players(local);
        }
    }
}

#altushkaso2