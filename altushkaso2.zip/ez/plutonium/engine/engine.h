#include <thread>
#include <chrono>
#include <unordered_map>

namespace engine {
    constexpr std::unordered_map<std::string, const char*> method_names = {
        {"on_occlusion_became_visible",   "HFCEDAECDAAEGDB"},
        {"on_occlusion_became_invisible", "EFGEFGHEBGDFCCA"},
        {"execute_commands",              "BFHDEEHAGCEHEBB"},
        {"player_serialize",              "AFEGEDFCABEEHHC"}
    };

    void init(plutonium_t &_cheat) {
        il2cpp_addr = _cheat._il2cpp->address();
        _itcu       = _cheat._itcu;

        axlebolt::init(_cheat);
        unity::init(_cheat);

        // ** Инициализация хуков **
        auto *fmod_manager_class = _itcu->find_class(nullptr, "FMODRuntimeManagerOnGUIHelper");
        if (fmod_manager_class) {
            _itcu->method_hook(fmod_manager_class, "OnGUI", fmod_runtime_manager_ongui_helper__ongui, &orig_fmod_runtime_manager_ongui_helper__ongui);
        }

        // ** Создаём GameObject для plutonium **
        auto attached_thread = il2cpp::thread::attach();
        auto *game_object_class = _itcu->find_class(nullptr, "GameObject");
        if (game_object_class) {
            auto game_obj = il2cpp::object::create<unity::game_object>(game_object_class);
            if (game_obj) {
                game_obj->create(il2cpp::string::create("plutonium"));

                auto component_type = unity::type::from_class(fmod_manager_class);
                if (component_type) {
                    game_obj->add_component(component_type);
                }
            }
        }
        attached_thread->detach();

        // ** Хук на PlayerController **
        auto *player_class = _itcu->find_class(nullptr, "PlayerController");
        if (player_class) {
            _itcu->method_hook(player_class, "Update", player_controller__update, &axlebolt::player_controller::orig_update);
            
            auto method = _itcu->find_method(player_class, method_names.at("on_occlusion_became_visible"));
            if (method) {
                _itcu->vmethod_hook<void*, void*>(player_class, method_names.at("on_occlusion_became_invisible"), method->methodPointer);
            }
        }

        // ** Хук на GunController **
        auto *gun_class = _itcu->find_class(nullptr, "GunController");
        if (gun_class) {
            _itcu->vmethod_hook(gun_class, method_names.at("execute_commands"), gun_controller__execute_commands, &axlebolt::gun_controller::execute_commands);
        }

        // ** Хук на PlayerSnapshot **
        auto *snapshot_class = _itcu->find_class(nullptr, "EBDGEEAAEDFECGE");
        if (snapshot_class) {
            _itcu->vmethod_hook(snapshot_class, method_names.at("player_serialize"), hk_player_snapshot__serialize, &axlebolt::player_snapshot::serialize);
        }

        // ** Ожидание загрузки call_raycast **
        void *call_raycast = reinterpret_cast<void*>(_g_cheat.load()->_il2cpp->address() + 0x538AB20);
        while (!*reinterpret_cast<void**>(call_raycast)) {
            std::this_thread::sleep_for(std::chrono::milliseconds(10)); // Ждём 10 мс вместо `sleep(1)`
        }

        // ** Устанавливаем хук на Internal_Raycast_Injected **
        bypass::icall_hook(call_raycast,
                           "UnityEngine.PhysicsScene::Internal_Raycast_Injected(UnityEngine.PhysicsScene&, UnityEngine.Ray&, "
                           "System.Single, UnityEngine.RaycastHit&, System.Int32, UnityEngine.QueryTriggerInteraction)",
                           hk_raycast, &orig_raycast);
    }
}
 #ALTUSHKASO2