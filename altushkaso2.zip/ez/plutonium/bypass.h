namespace bypass {
    struct hook_info {
        void *ptr_addr;
        void *hook_addr;
        void *orig_addr;
        bool is_swap_hook;

        explicit hook_info(void *ptr, void *hook, void *orig, bool swap)
            : ptr_addr(ptr), hook_addr(hook), orig_addr(orig), is_swap_hook(swap) {}
    };

    std::vector<std::shared_ptr<hook_info>> hooked_funcs;

    template<class H, class O>
    void icall_hook(void *delegate_addr, const char *method_name, H hook, O orig, const char *dll = "libunity") {
        try {
            auto info = std::make_shared<hook_info>(delegate_addr, (void *) hook, nullptr, false);
            auto _icall = std::make_unique<il2cpp::icall>(dll, method_name);

            void *orig_addr = (!strcmp(dll, "libunity")) ? _icall->resolve_icall_unity() : _icall->resolve_icall();
            if (orig) *reinterpret_cast<void **>(orig) = orig_addr;

            info->orig_addr = orig_addr;
            hooked_funcs.push_back(info);
            *reinterpret_cast<void **>(delegate_addr) = (void *) hook;
        } catch (const std::exception &e) {
            LOGD("icall_hook failed: %s", e.what());
        }
    }

    template<class H, class O>
    void swap_ptr(void *addr, H hook, O orig) {
        try {
            auto info = std::make_shared<hook_info>(addr, (void *) hook, *reinterpret_cast<void **>(addr), true);
            hooked_funcs.push_back(info);
            menu_includes::hook(addr, (void *) hook, reinterpret_cast<void **>(orig));
        } catch (const std::exception &e) {
            LOGD("swap_ptr failed: %s", e.what());
        }
    }

    void *(*orig_shared_getrr)(const char *id, const char *report_arg);

    void *hk_shared_getrr(const char *id, const char *report_arg) {
        LOGD("reparg: %s", report_arg);

        for (const auto &info : hooked_funcs) {
            if (info->is_swap_hook) {
                menu_includes::hook(info->ptr_addr, info->orig_addr, nullptr);
            } else {
                *reinterpret_cast<void **>(info->ptr_addr) = info->orig_addr;
            }
            LOGD("Restored original: ptr: %p, orig: %p, hook: %p, swap: %d",
                 info->ptr_addr, info->orig_addr, info->hook_addr, info->is_swap_hook);
        }

        void *result = orig_shared_getrr(id, report_arg);

        for (const auto &info : hooked_funcs) {
            if (info->is_swap_hook) {
                menu_includes::hook(info->ptr_addr, info->hook_addr, nullptr);
            } else {
                *reinterpret_cast<void **>(info->ptr_addr) = info->hook_addr;
            }
            LOGD("Re-hooked: ptr: %p, orig: %p, hook: %p, swap: %d",
                 info->ptr_addr, info->orig_addr, info->hook_addr, info->is_swap_hook);
        }

        return result;
    }

    void init(plutonium_t &cheat) {
        void *getrr_delegate = reinterpret_cast<void *>(cheat._il2cpp->address() + 0x51186B8);
        icall_hook(getrr_delegate, "_Unwind_GetRR", hk_shared_getrr, &orig_shared_getrr, "libshared");
    }
}
 #altushkaso2