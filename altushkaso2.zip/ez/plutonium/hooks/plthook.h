#include <vector>
#include <fcntl.h>
#include <cstring>
#include <unistd.h>
#include <dlfcn.h>
#include <elf.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>

#define PAGE_ALIGN(addr) ((void *)((size_t)(addr) & ~(sysconf(_SC_PAGESIZE) - 1)))

struct HookInfo {
    std::string library_name;
    std::string function_name;
    void *original_function;
    void *hook_function;
};

class PLTHookManager {
private:
    std::vector<HookInfo> hooks;

    int get_memory_permission(void *address) {
        unsigned long addr = (unsigned long)address;
        FILE *fp;
        char buf[512], perms[5];

        fp = fopen("/proc/self/maps", "r");
        if (!fp) return 0;

        while (fgets(buf, sizeof(buf), fp)) {
            unsigned long start, end;
            if (sscanf(buf, "%lx-%lx %4s", &start, &end, perms) == 3) {
                if (start <= addr && addr < end) {
                    fclose(fp);
                    int prot = 0;
                    if (perms[0] == 'r') prot |= PROT_READ;
                    if (perms[1] == 'w') prot |= PROT_WRITE;
                    if (perms[2] == 'x') prot |= PROT_EXEC;
                    return prot;
                }
            }
        }
        fclose(fp);
        return 0;
    }

public:
    bool hook(const char *so_name, const char *function_name, void *replacement) {
        Dl_info info;
        uintptr_t so_addr = (uintptr_t)dlsym(RTLD_DEFAULT, so_name);
        if (!so_addr) return false;

        if (!dladdr((void *)so_addr, &info)) return false;

        int fd = open(info.dli_fname, O_RDONLY);
        if (fd == -1) return false;

        struct stat st;
        if (fstat(fd, &st) == -1) {
            close(fd);
            return false;
        }

        void *header = mmap(nullptr, st.st_size, PROT_READ, MAP_PRIVATE, fd, 0);
        close(fd);

        if (header == MAP_FAILED) return false;

        Elf64_Ehdr *ehdr = (Elf64_Ehdr *)header;
        Elf64_Phdr *phdr = (Elf64_Phdr *)((char *)header + ehdr->e_phoff);
        Elf64_Shdr *shdr = (Elf64_Shdr *)((char *)header + ehdr->e_shoff);

        Elf64_Shdr *dynamic_shdr = nullptr;
        for (int i = 0; i < ehdr->e_shnum; i++) {
            if (shdr[i].sh_type == SHT_DYNAMIC) {
                dynamic_shdr = &shdr[i];
                break;
            }
        }
        if (!dynamic_shdr) {
            munmap(header, st.st_size);
            return false;
        }

        Elf64_Dyn *dynamic = (Elf64_Dyn *)((char *)header + dynamic_shdr->sh_offset);
        Elf64_Sym *symtab = nullptr;
        Elf64_Rela *plt_rela = nullptr;
        size_t plt_rela_count = 0;
        const char *strtab = nullptr;

        for (int i = 0; dynamic[i].d_tag != DT_NULL; i++) {
            if (dynamic[i].d_tag == DT_JMPREL)
                plt_rela = (Elf64_Rela *)((char *)header + dynamic[i].d_un.d_ptr);
            if (dynamic[i].d_tag == DT_PLTRELSZ)
                plt_rela_count = dynamic[i].d_un.d_val / sizeof(Elf64_Rela);
            if (dynamic[i].d_tag == DT_SYMTAB)
                symtab = (Elf64_Sym *)((char *)header + dynamic[i].d_un.d_ptr);
            if (dynamic[i].d_tag == DT_STRTAB)
                strtab = (const char *)((char *)header + dynamic[i].d_un.d_ptr);
        }

        for (size_t k = 0; k < plt_rela_count; k++) {
            uint32_t r_sym = ELF64_R_SYM(plt_rela[k].r_info);
            uint32_t r_type = ELF64_R_TYPE(plt_rela[k].r_info);

            if (r_type == R_AARCH64_JUMP_SLOT) {
                const char *symbol_name = strtab + symtab[r_sym].st_name;

                if (!strcmp(symbol_name, function_name)) {
                    void *rel_target = (void *)(so_addr + plt_rela[k].r_offset);
                    void *&rel_addr = *(void **)rel_target;

                    int orig_perms = get_memory_permission(PAGE_ALIGN(rel_target));
                    if (orig_perms == 0) continue;

                    mprotect(PAGE_ALIGN(rel_target), sysconf(_SC_PAGESIZE), PROT_READ | PROT_WRITE);
                    void *original_function = rel_addr;
                    rel_addr = replacement;
                    mprotect(PAGE_ALIGN(rel_target), sysconf(_SC_PAGESIZE), orig_perms);

                    hooks.push_back({so_name, function_name, original_function, replacement});

                    munmap(header, st.st_size);
                    return true;
                }
            }
        }
        munmap(header, st.st_size);
        return false;
    }

    void *get_original_function(const char *function_name) {
        for (const auto &hook : hooks) {
            if (hook.function_name == function_name) {
                return hook.original_function;
            }
        }
        return nullptr;
    }

    std::vector<HookInfo> get_all_hooks() {
        return hooks;
    }
};

 #altushkaso2