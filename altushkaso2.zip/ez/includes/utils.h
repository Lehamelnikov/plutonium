#ifndef ZYGISK_IMGUI_MODMENU_UTILS_H
#define ZYGISK_IMGUI_MODMENU_UTILS_H

#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>
#include <string_view>

// ** Оптимизированные inline-функции вместо макросов **
constexpr bool inRange(char x, char a, char b) {
    return (x >= a && x <= b);
}

constexpr int getBits(char x) {
    return inRange(x, '0', '9') ? (x - '0') : ((x & (~0x20)) - 'A' + 0xA);
}

constexpr int getByte(std::string_view x) {
    return (getBits(x[0]) << 4 | getBits(x[1]));
}

// ** Оптимизированные system call номера **
#if defined(__arm__)
constexpr int process_vm_readv_syscall = 376;
constexpr int process_vm_writev_syscall = 377;
#elif defined(__aarch64__)
constexpr int process_vm_readv_syscall = 270;
constexpr int process_vm_writev_syscall = 271;
#elif defined(__i386__)
constexpr int process_vm_readv_syscall = 347;
constexpr int process_vm_writev_syscall = 348;
#else
constexpr int process_vm_readv_syscall = 310;
constexpr int process_vm_writev_syscall = 311;
#endif

namespace utils {
    struct module_info {
        void* start_address{nullptr};
        void* end_address{nullptr};
        size_t size{0};
        std::string name;
        int perms{0};

        // ** Конструктор по умолчанию **
        module_info() = default;

        // ** Конструктор с параметрами **
        explicit module_info(std::string_view module_name)
            : name(module_name) {}

        // ** Запрещаем копирование, но разрешаем перемещение **
        module_info(const module_info&) = delete;
        module_info& operator=(const module_info&) = delete;
        module_info(module_info&&) noexcept = default;
        module_info& operator=(module_info&&) noexcept = default;
    };

    [[nodiscard]] int get_android_api_level();
    [[nodiscard]] bool read_address(void* address, void* out_buffer, size_t length);
    [[nodiscard]] bool write_address(void* address, void* in_buffer, size_t length);

    [[nodiscard]] module_info find_module(std::string_view name);
    [[nodiscard]] std::vector<module_info> find_modules(void* address);
    
    [[nodiscard]] uintptr_t find_pattern(uint8_t* start, size_t length, std::string_view pattern);
    [[nodiscard]] uintptr_t find_pattern_in_module(std::string_view lib_name, std::string_view pattern);
}

#endif // ZYGISK_IMGUI_MODMENU_UTILS_H
  #altushkaso2