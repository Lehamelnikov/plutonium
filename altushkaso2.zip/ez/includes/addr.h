#define _GNU_SOURCE
#include <cstdio>
#include <cstdlib>
#include <link.h>
#include <vector>
#include <memory>
#include <string>

struct dl_error {
    std::string error;
    explicit dl_error(const std::string& e = "cannot find") : error(e) {}
};

struct section_data {
    std::string name;
    uintptr_t address{0};
    bool found{false};

    explicit section_data(std::string n) : name(std::move(n)) {}
};

class Library {
private:
    std::string library_name;
    uintptr_t address{0};
    bool found{false};
    std::vector<dl_error> errors;

    static int callback(struct dl_phdr_info *info, size_t size, void *data);

public:
    explicit Library(const std::string& library_name);
    void GetLibrary();
    
    uintptr_t GetAddress() const { return address; }
    const std::vector<dl_error>& GetErrors() const { return errors; }
    bool Loaded() const { return found; }
};

int Library::callback(struct dl_phdr_info *info, size_t, void *data) {
    auto* sectionData = static_cast<section_data*>(data);
    if (info->dlpi_name && strstr(info->dlpi_name, sectionData->name.c_str())) {
        sectionData->address = info->dlpi_addr;
        sectionData->found = true;
        return 1; // Остановить итерацию, если найдена библиотека
    }
    return 0;
}

void Library::GetLibrary() {
    section_data data(library_name);
    if (!dl_iterate_phdr(callback, &data)) {
        errors.emplace_back();
    } else {
        address = data.address;
        found = data.found;
    }
}

Library::Library(const std::string& library_name) : library_name(library_name) {
    GetLibrary();
}
 #byaltushkaso2