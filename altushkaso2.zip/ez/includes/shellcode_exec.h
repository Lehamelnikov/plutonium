#define _GNU_SOURCE
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <atomic>
#include <sys/mman.h>
#include <sys/prctl.h>
#include <unistd.h>

struct segment_t {
    void *segment_start;
    size_t segment_size;
    int perms;
};

struct remap_t {
    void *mmap_function;
    void *mmap64_function;
    void *mprotect_function;
    void *mincore_function;
    void *malloc_function;
    void *usleep_function;
    void *prctl_function;

    void *zygisk_module_bytes;
    void *zygisk_module_base;
    void *return_address;

    uint32_t zygisk_module_size;
    segment_t *segments;
    size_t segments_count;
    size_t load_size;

    const char *bss_vma_name;
    const char *module_vma_name;
};

void *allocate_memory(void *addr, size_t size, int prot, int flags) {
    return mmap(addr, size, prot, flags, -1, 0);
}

void *remap_thread_shellcode(void *arg) {
    auto *_remap = static_cast<remap_t *>(arg);
    if (!_remap) return nullptr;

    auto _mmap = reinterpret_cast<void *(*)(void *, size_t, int, int, int, off_t)>(_remap->mmap_function);
    auto _mmap64 = reinterpret_cast<void *(*)(void *, size_t, int, int, int, off_t)>(_remap->mmap64_function);
    auto _mprotect = reinterpret_cast<int (*)(const void *, size_t, int)>(_remap->mprotect_function);
    auto _mincore = reinterpret_cast<int (*)(void *, size_t, unsigned char *)>(_remap->mincore_function);
    auto _prctl = reinterpret_cast<int (*)(int, ...)>(_remap->prctl_function);
    auto _usleep = reinterpret_cast<int (*)(useconds_t)>(_remap->usleep_function);

    void *zygisk_module_base = _remap->zygisk_module_base;
    uint32_t zygisk_module_size = _remap->zygisk_module_size;

    char *buffer = static_cast<char *>(_remap->zygisk_module_bytes);
    auto *header = reinterpret_cast<Elf64_Ehdr *>(buffer);
    auto *phdr = reinterpret_cast<Elf64_Phdr *>(buffer + header->e_phoff);

    while (zygisk_module_base) {
        unsigned char *vec = static_cast<unsigned char *>(malloc(sizeof(unsigned char)));
        if (!vec) break;

        int mincore_result = _mincore(zygisk_module_base, 4096, vec);
        if (mincore_result == -1 || vec[0] == 0) {
            void *remapped_module = _mmap(zygisk_module_base, _remap->load_size, PROT_READ | PROT_WRITE, MAP_FIXED | MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
            if (!remapped_module) break;

            uintptr_t load_bias = reinterpret_cast<uintptr_t>(remapped_module);
            auto *remapped_module_bytes = static_cast<uint8_t *>(remapped_module);
            auto *zygisk_module_bytes = static_cast<uint8_t *>(_remap->zygisk_module_bytes);

            for (int i = 0; i < header->e_phnum; i++) {
                Elf64_Addr seg_start = phdr[i].p_vaddr + load_bias;
                Elf64_Addr seg_end = seg_start + phdr[i].p_memsz;
                Elf64_Addr seg_page_start = page_start(seg_start);
                Elf64_Addr seg_page_end = page_end(seg_end);
                Elf64_Addr seg_file_end = seg_start + phdr[i].p_filesz;
                Elf64_Addr file_start = phdr[i].p_offset;
                Elf64_Addr file_end = file_start + phdr[i].p_filesz;
                Elf64_Addr file_page_start = page_start(file_start);
                Elf64_Addr file_length = file_end - file_page_start;

                _mmap64(reinterpret_cast<void *>(seg_page_start), file_length, PROT_READ | PROT_WRITE | PROT_EXEC, MAP_FIXED | MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);

                seg_file_end = page_end(seg_file_end);
                if (seg_page_end > seg_file_end) {
                    size_t zeromap_size = seg_page_end - seg_file_end;
                    void *zeromap = _mmap(reinterpret_cast<void *>(seg_file_end), zeromap_size, PROT_READ | PROT_WRITE, MAP_FIXED | MAP_ANONYMOUS | MAP_PRIVATE, -1, 0);
                    _prctl(PR_SET_VMA, PR_SET_VMA_ANON_NAME, zeromap, zeromap_size, _remap->bss_vma_name);
                }
            }

            memcpy(remapped_module_bytes, zygisk_module_bytes, zygisk_module_size);

            for (size_t i = 0; i < _remap->segments_count; i++) {
                segment_t &_segment = _remap->segments[i];
                if (_segment.perms & PROT_EXEC) {
                    _prctl(PR_SET_VMA, PR_SET_VMA_ANON_NAME, _segment.segment_start, _segment.segment_size, _remap->module_vma_name);
                }
                _mprotect(_segment.segment_start, _segment.segment_size, _segment.perms);
            }

            return _remap->return_address;
        }

        _usleep(100);
    }

    return nullptr;
}

namespace shellcode_executor {
    std::atomic<bool> shellcode_called{};
    void *g_shellcode{};

    class shellcode_t {
    private:
        void *shellcode{nullptr};

    public:
        void *get_shellcode() {
            if (!shellcode) {
                abort();
            }
            return shellcode;
        }

        void allocate_shellcode() {
            shellcode = mmap64(nullptr, sizeof(function_shellcode), PROT_READ | PROT_WRITE | PROT_EXEC, MAP_ANONYMOUS | MAP_PRIVATE, -1, 0);
            if (!shellcode) {
                abort();
            }
            memcpy(shellcode, function_shellcode, sizeof(function_shellcode));
            prctl(PR_SET_VMA, PR_SET_VMA_ANON_NAME, shellcode, sizeof(function_shellcode), "libc_malloc");
            LOGD("Shellcode allocated at: %p", shellcode);
        }

        shellcode_t() = default;
    };

    shellcode_t _shellcode;

    void *get_shellcode() {
        return _shellcode.get_shellcode();
    }

    void allocate_shellcode() {
        _shellcode.allocate_shellcode();
    }
} 
  #altushkaso2