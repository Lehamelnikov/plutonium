#include <cstring>
#include <thread>
#include <vector>
#include <memory>
#include <chrono>
#include <unordered_map>
#include <dlfcn.h>
#include <pthread.h>
#include <sys/mman.h>
#include <unistd.h>
#include <elf.h>
#include "includes/plutonium.h"
#include "includes/zygisk.hpp"
#include "includes/game.h"
#include "includes/log.h"
#include "includes/utils.h"
#include "includes/shellcode_exec.h"
#include "plutonium/hooks/plthook.h"

using namespace std;
using namespace zygisk;

class PlutoniumRemapper : public ModuleBase {
public:
    void onLoad(Api *api, JNIEnv *env) override {
        this->api = api;
        this->env = env;
    }

    void preAppSpecialize(AppSpecializeArgs *args) override {
        const char *package_name = env->GetStringUTFChars(args->nice_name, nullptr);
        const char *app_data_dir = env->GetStringUTFChars(args->app_data_dir, nullptr);
        
        if (strcmp(package_name, GamePackageName) == 0) {
            LOGI("Detected game: %s", package_name);
            enable_hack = true;
            game_data_dir = make_unique<string>(app_data_dir);
        }

        env->ReleaseStringUTFChars(args->nice_name, package_name);
        env->ReleaseStringUTFChars(args->app_data_dir, app_data_dir);
    }

    void postAppSpecialize(const AppSpecializeArgs *) override {
        if (!enable_hack) return;

        Dl_info info;
        if (!dladdr((void *) remap_thread_shellcode, &info)) {
            LOGE("Failed to retrieve module info");
            return;
        }

        LOGD("Module base: %p", info.dli_fbase);

        vector<utils::module_info> modules = utils::find_modules(info.dli_fbase);
        if (modules.empty()) {
            LOGE("Failed to retrieve module segments");
            return;
        }

        size_t zygisk_module_size = (uintptr_t)modules.back().end_address - (uintptr_t)modules.front().start_address;
        LOGD("Module size: %zu (%p)", zygisk_module_size, zygisk_module_size);

        void *zygisk_module_bytes = malloc(zygisk_module_size);
        if (!zygisk_module_bytes) {
            LOGE("Memory allocation failed for module bytes");
            return;
        }

        LOGD("Module bytes allocated at %p", zygisk_module_bytes);
        memcpy(zygisk_module_bytes, info.dli_fbase, zygisk_module_size);

        vector<segment_t> segments;
        for (const auto &module : modules) {
            segment_t segment = {
                .segment_start = module.start_address,
                .segment_size  = module.size,
                .perms         = module.perms
            };
            segments.push_back(segment);
        }

        LOGD("Collected %zu segments", segments.size());

        remap_t remap = {
            .mmap_function     = dlsym(RTLD_DEFAULT, "mmap"),
            .mmap64_function   = dlsym(RTLD_DEFAULT, "mmap64"),
            .mprotect_function = dlsym(RTLD_DEFAULT, "mprotect"),
            .mincore_function  = dlsym(RTLD_DEFAULT, "mincore"),
            .malloc_function   = dlsym(RTLD_DEFAULT, "malloc"),
            .usleep_function   = dlsym(RTLD_DEFAULT, "usleep"),
            .prctl_function    = dlsym(RTLD_DEFAULT, "prctl"),

            .zygisk_module_bytes = zygisk_module_bytes,
            .zygisk_module_base  = info.dli_fbase,
            .return_address      = (void *) cheat_thread,
            .zygisk_module_size  = zygisk_module_size,

            .segments       = segments.data(),
            .segments_count = segments.size(),
            .load_size      = phdr_table_get_load_size(phdr, header->e_phnum, nullptr, nullptr),

            .bss_vma_name    = "g",
            .module_vma_name = "p"
        };

        auto remap_ptr = make_unique<remap_t>(remap);

        LOGI("Remap info: %p\n"
             "  mmap: %p\n"
             "  mprotect: %p\n"
             "  mincore: %p\n"
             "  malloc: %p\n"
             "  usleep: %p\n"
             "  module bytes: %p\n"
             "  module base: %p\n"
             "  module size: %zu\n"
             "  return address: %p\n"
             "  segments count: %zu",
             remap_ptr.get(),
             remap_ptr->mmap_function,
             remap_ptr->mprotect_function,
             remap_ptr->mincore_function,
             remap_ptr->malloc_function,
             remap_ptr->usleep_function,
             remap_ptr->zygisk_module_bytes,
             remap_ptr->zygisk_module_base,
             remap_ptr->zygisk_module_size,
             remap_ptr->return_address,
             remap_ptr->segments_count);

        pthread_t ptid;
        int result = pthread_create(&ptid, nullptr, cheat_thread, remap_ptr.get());
        if (result != 0) {
            LOGE("Failed to create pthread: %d", result);
            return;
        }

        LOGD("pthread created successfully, unloading module");
        sleep(1);

        api->setOption(zygisk::Option::DLCLOSE_MODULE_LIBRARY);
    }

private:
    Api *api;
    JNIEnv *env;
    bool enable_hack = false;
    unique_ptr<string> game_data_dir;
};

REGISTER_ZYGISK_MODULE(PlutoniumRemapper);
   #byaltushkaso2