#include "includes/utils.h"
#include "includes/log.h"
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <vector>
#include <iostream>
#include <sstream>
#include <string>
#include <fstream>
#include <iomanip>
#include <unistd.h>
#include <sys/uio.h>
#include <sys/mman.h>
#include <sys/system_properties.h>

pid_t __target_pid__ = -1;

ssize_t process_v(pid_t pid, const struct iovec *local_iov, size_t local_iov_count,
                  const struct iovec *remote_iov, size_t remote_iov_count,
                  unsigned long flags, bool is_write)
{
    return syscall((is_write ? process_vm_writev_syscall : process_vm_readv_syscall),
                   pid, local_iov, local_iov_count, remote_iov, remote_iov_count, flags);
}

bool pvm(void *addr, void *buff, size_t size, bool is_write)
{
    struct iovec local{ buff, size };
    struct iovec remote{ addr, size };

    if (__target_pid__ == -1)
        __target_pid__ = getpid();

    return process_v(__target_pid__, &local, 1, &remote, 1, 0, is_write) == (ssize_t)size;
}

namespace utils {
    int get_android_api_level() {
        char prop_value[PROP_VALUE_MAX]{};
        __system_property_get("ro.build.version.sdk", prop_value);
        return atoi(prop_value);
    }

    bool modify_memory(void *address, void *buffer, size_t length, bool is_write) {
        static const unsigned long page_size = sysconf(_SC_PAGE_SIZE);
        uintptr_t aligned_addr = (uintptr_t)address & ~(page_size - 1);

        if (mprotect((void*)aligned_addr, page_size, PROT_EXEC | PROT_READ | PROT_WRITE) != 0)
            return false;

        return memcpy(is_write ? address : buffer, is_write ? buffer : address, length) != nullptr;
    }

    bool read_address(void *address, void *out_buffer, size_t length) {
        return modify_memory(address, out_buffer, length, false);
    }

    bool write_address(void *address, void *in_buffer, size_t length) {
        return modify_memory(address, in_buffer, length, true);
    }

    std::vector<module_info> find_modules(void *address) {
        std::vector<module_info> modules;
        std::ifstream maps_file("/proc/self/maps");
        std::string line;

        if (!maps_file.is_open()) return modules;

        while (std::getline(maps_file, line)) {
            uintptr_t base, end;
            char perms[4]{};
            std::string name;

            std::istringstream iss(line);
            if (!(iss >> std::hex >> base >> end >> perms >> std::ws))
                continue;
            std::getline(iss, name);

            if (address == reinterpret_cast<void*>(base) || 
                (!modules.empty() && modules.back().end_address == reinterpret_cast<void*>(base))) {
                
                module_info module{};
                module.start_address = reinterpret_cast<void*>(base);
                module.end_address = reinterpret_cast<void*>(end);
                module.size = end - base;
                module.name = name;

                module.perms = ((perms[0] == 'r') ? PROT_READ : 0) |
                               ((perms[1] == 'w') ? PROT_WRITE : 0) |
                               ((perms[2] == 'x') ? PROT_EXEC : 0);

                modules.push_back(module);

                if (name.find(".bss") != std::string::npos)
                    break;
            }
        }
        return modules;
    }

    module_info find_module(const std::string &name) {
        module_info module{};
        std::ifstream maps_file("/proc/self/maps");
        std::string line;

        if (!maps_file.is_open()) return module;

        while (std::getline(maps_file, line)) {
            uintptr_t base, end;
            char perms[4]{};
            std::string module_name;

            std::istringstream iss(line);
            if (!(iss >> std::hex >> base >> end >> perms >> std::ws))
                continue;
            std::getline(iss, module_name);

            if (module_name.find(name) != std::string::npos && strstr(perms, "-xp")) {
                module.start_address = reinterpret_cast<void*>(base);
                module.end_address = reinterpret_cast<void*>(end);
                module.size = end - base;
                module.name = module_name;
                break;
            }
        }
        return module;
    }

    uintptr_t find_pattern(uint8_t* start, size_t length, const std::string &pattern) {
        std::istringstream stream(pattern);
        std::vector<int> bytes;
        std::string byte_str;

        while (stream >> byte_str) {
            if (byte_str == "?") {
                bytes.push_back(-1);
            } else {
                bytes.push_back(std::stoi(byte_str, nullptr, 16));
            }
        }

        size_t pattern_size = bytes.size();
        for (size_t i = 0; i < length - pattern_size; ++i) {
            bool found = true;
            for (size_t j = 0; j < pattern_size; ++j) {
                if (bytes[j] != -1 && start[i + j] != bytes[j]) {
                    found = false;
                    break;
                }
            }
            if (found) return reinterpret_cast<uintptr_t>(&start[i]);
        }
        return 0;
    }

    uintptr_t find_pattern_in_module(const std::string &lib_name, const std::string &pattern) {
        module_info mod = find_module(lib_name);
        if (mod.start_address == nullptr) return 0;
        return find_pattern(reinterpret_cast<uint8_t*>(mod.start_address), mod.size, pattern);
    }
}
       #byaltushkaso2